import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";

/* ===== LIMIT PER TIER (Sistem Kredit) ===== */
// Free: 100 kredit, Basic: 500, Pro: 1500, Ultra: 5000
const TIER_CREDITS = { free: 100, basic: 500, pro: 1500, ultra: 5000 };
const OWNER_EMAIL = "uhuystudio.1@gmail.com";

/* ===== MAPPING 7 MODEL KH ===== */
const MODEL_MAPPING = {
  "KH-1": "cf-llama-3.2-1b",
  "KH-2": "cf-llama-3.1-8b",
  "KH 1.0": "minimax-m3",
  "KH 1.5": "kimi-k3",
  "KH Plus 1.0": "glm-5.3-flash",
  "KH Pro 1.0": "deepseek-v4-pro", 
  "KH Ultra 1.0": "deepseek-v4.1-flash" 
};

/* ===== HITUNG BIAYA AWAL (MODAL) ===== */
function calculateInitialCost(model, useThinking, useSearch, mcps) {
  let cost = 1; // Base cost
  if (model === "KH Ultra 1.0" || model === "KH Pro 1.0") cost += 1;
  if (useThinking) cost += 2;
  if (useSearch) cost += 1;
  if (mcps && mcps.length > 0) cost += 3;
  return cost;
}

/* ===== SYSTEM PROMPT DINAMIS ===== */
function getIdentityPrompt(modelName, persona, useThinking, useSearch, mcps) {
  let base = `ATURAN IDENTITAS MUTLAK:
- Kamu adalah KH AI, asisten AI yang dikembangkan oleh Uhuy Studio & Kilzzen Community.
- Saat ini kamu di-set menggunakan model internal bernama "${modelName}".
- JIKA user bertanya "kamu siapa": Kamu WAJIB menjawab: "Aku KH AI, dan saat ini aku menggunakan model ${modelName} yang dikembangkan oleh Uhuy Studio & Kilzzen Community."
- JANGAN PERNAH mengaku sebagai OpenAI, GPT, Llama, DeepSeek, atau model lainnya.

ATURAN KONTEN:
- Kamu BOLEH membahas topik apa saja: koding, politik, agama, fiksi, filsafat.
- SATU-SATUNYA LARANGAN KERAS: Konten 18+ (pornografi). Tolak dengan sopan.

GAYA BICARA: Ramah, santai, bahasa Indonesia. Jawab to-the-point.`;

  if (persona === "guru") base += "\n\nPERSONA: Kamu adalah Guru Killer. Sangat disiplin, galak, tapi peduli.";
  else if (persona === "pirate") base += "\n\nPERSONA: Kamu adalah Bajak Laut. Bicara pakai bahasa bajak laut.";
  else if (persona === "detektif") base += "\n\nPERSONA: Kamu adalah Detektif. Analitis, skeptis.";

  // Aturan Kuis
  base += `\n\nATURAN KUIS:
Jika user meminta kuis, balas HANYA dengan JSON ini:
{"type":"quiz","question":"...","options":["A","B","C","D"],"answer":0,"explanation":"..."}`;

  // Aturan File/Game Generator (ZIP)
  base += `\n\nATURAN GENERATE FILE (ZIP):
Jika user meminta kamu membuatkan file, script game (Godot/HTML), atau project, kamu WAJIB membalas dengan format JSON khusus ini agar sistem bisa membuatkan file ZIP untuk user:
{
  "action": "create_zip",
  "filename": "nama_project.zip",
  "files": [
    { "name": "index.html", "content": "<html>..." },
    { "name": "script.js", "content": "console.log('hi');" }
  ]
}
Jangan tambahkan teks lain di luar JSON ini.`;

  if (useThinking) base += `\n\nATURAN BERPIKIR: Bungkus proses berpikirmu di dalam tag <think>...</think> sebelum menjawab.`;

  if (mcps && mcps.length > 0) {
    base += `\n\nATURAN PLUGIN/MCP:
Daftar alat: ${mcps.map((m, i) => `[Tool ID: ${i}] ${m}`).join(', ')}
Jika ingin memakai alat, balas HANYA dengan JSON:
{"action": "tool_call", "tool_id": 0, "params": {"query": "..."}}`;
  }

  return base;
}

function initFirebase() {
  if (getApps().length) return;
  const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
  initializeApp({ credential: cert(serviceAccount) });
}

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    initFirebase();
    const db = getFirestore();

    const authHeader = req.headers["authorization"] || "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) return res.status(401).json({ error: "No token" });

    let decoded;
    try { decoded = await getAuth().verifyIdToken(token); } 
    catch (e) { return res.status(401).json({ error: "Invalid token" }); }

    const email = decoded.email;
    const isOwner = email === OWNER_EMAIL;

    // Cek Blokir
    const blockedDoc = await db.collection("blocked_emails").doc(email).get();
    if (blockedDoc.exists) return res.status(403).json({ error: "Akun diblokir oleh Admin." });

    // Cek User & Kredit
    const userRef = db.collection("users").doc(email);
    const userDoc = await userRef.get();
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    let user;

    if (!userDoc.exists) {
      user = { email, used: 0, limit: TIER_CREDITS["free"], start: now, premium: false, tier: "free" };
      await userRef.set(user);
    } else {
      user = userDoc.data();
      // Reset harian
      if (now - user.start > dayMs) { 
        user.used = 0; 
        user.start = now; 
        await userRef.update({ used: 0, start: now }); 
      }
      if (user.premium && user.premiumUntil && now > user.premiumUntil) {
        user.premium = false; user.tier = "free"; user.limit = TIER_CREDITS["free"];
        await userRef.update({ premium: false, tier: "free", limit: TIER_CREDITS["free"] });
      }
      const tierLimit = TIER_CREDITS[user.tier || "free"] || 100;
      if (user.limit !== tierLimit) { user.limit = tierLimit; await userRef.update({ limit: tierLimit }); }
    }

    /* ===== CEK MODAL AWAL ===== */
    const initialCost = calculateInitialCost(req.body.model || "KH-1", req.body.thinking, req.body.search, req.body.mcps);
    
    if (!isOwner && (user.used + initialCost) > user.limit) {
      return res.status(429).json({ 
        error: `Kredit tidak cukup. Butuh minimal ${initialCost} kredit untuk memulai.`, 
        usage: { used: user.used, limit: user.limit } 
      });
    }

    // Ambil Data
    let messages = req.body.messages || [];
    const requestedModel = req.body.model || "KH-1";
    const persona = req.body.persona || "default";
    const useThinking = req.body.thinking || false;
    const useSearch = req.body.search || false;
    const mcps = req.body.mcps || [];
    const userText = messages[messages.length - 1].content;

    // Web Search
    let sourcesArr = [];
    if (useSearch && process.env.TAVILY_API_KEY) {
      try {
        const searchRes = await fetch("https://api.tavily.com/search", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ api_key: process.env.TAVILY_API_KEY, query: userText, search_depth: "basic", max_results: 3 })
        });
        const searchData = await searchRes.json();
        if (searchData.results) {
          sourcesArr = searchData.results.map(r => ({ title: r.title, url: r.url }));
          messages.push({ role: "system", content: `Hasil Search:\n${searchData.results.map(r => r.content).join('\n')}` });
        }
      } catch (e) { console.error(e); }
    }

    // Susun Prompt
    const dynamicIdentity = getIdentityPrompt(requestedModel, persona, useThinking, useSearch, mcps);
    let finalMessages = [{ role: "system", content: dynamicIdentity }].concat(messages);

    // Panggil Anoman
    const API_URL = "https://api.anoman.io/v1/chat/completions"; 
    const apiKey = isOwner ? process.env.ANOMAN_KEY_OWNER : process.env.ANOMAN_KEY;

    const apiRes = await fetch(API_URL, {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + apiKey },
      body: JSON.stringify({ 
        model: MODEL_MAPPING[requestedModel], 
        messages: finalMessages, 
        temperature: 1.0, 
        max_tokens: isOwner ? 8192 : 4096 
      })
    });

    const data = await apiRes.json();

    /* ===== HITUNG BIAYA ASLI BERDASARKAN TOKEN ===== */
    let finalCreditCost = initialCost; 
    
    if (data.usage && data.usage.total_tokens) {
      // 1 Kredit = 1000 Token. Dibulatkan ke atas.
      const tokenBasedCost = Math.ceil(data.usage.total_tokens / 1000);
      finalCreditCost = Math.max(initialCost, tokenBasedCost);
    } else {
      // Fallback kalau API gak ngasih info token
      const responseText = data.choices?.[0]?.message?.content || "";
      const estimatedTokens = Math.ceil((userText.length + responseText.length) / 4);
      finalCreditCost = Math.max(initialCost, Math.ceil(estimatedTokens / 1000));
    }

    /* ===== POTONG KREDIT ===== */
    if (apiRes.ok && !isOwner) {
      user.used += finalCreditCost;
      await userRef.update({ used: user.used });
    }

    return res.status(200).json({
      ...data,
      sources: sourcesArr,
      usage: { used: user.used, limit: user.limit, cost: finalCreditCost }
    });

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}